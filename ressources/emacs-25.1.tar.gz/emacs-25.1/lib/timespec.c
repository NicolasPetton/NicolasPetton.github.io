#include <config.h>
#define _GL_TIMESPEC_INLINE _GL_EXTERN_INLINE
#include "timespec.h"
